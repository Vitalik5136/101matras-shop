// Імітація KeyCRM і monobank для локальної перевірки (не використовується в роботі магазину)
const http = require('http');
const log = [];
const invoices = {};
http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    const j = body ? JSON.parse(body) : null;
    log.push({ m: req.method, u: req.url, h: { auth: req.headers.authorization, xt: req.headers['x-token'] }, j });
    const send = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
    const u = req.url;
    if (u === '/__log') return send(200, log);
    if (u.startsWith('/v1/order/source')) return send(200, { data: [{ id: 3, name: 'Instagram' }, { id: 7, name: 'Сайт-магазин' }] });
    if (u.startsWith('/v1/order/payment-method')) return send(200, { data: [{ id: 1, name: 'Готівка' }, { id: 4, name: 'monobank' }] });
    if (u === '/v1/order' && req.method === 'POST') return send(201, { id: 5123, ...j });
    if (/^\/v1\/order\/\d+\/payment$/.test(u)) return send(201, { id: 1, ...j });
    if (/^\/v1\/order\/\d+/.test(u)) return send(200, { id: 5123, manager_comment: 'x', payments: [] });
    if (u === '/api/merchant/invoice/create') { const id = 'inv' + Date.now(); invoices[id] = j; return send(200, { invoiceId: id, pageUrl: 'https://pay.example/' + id }); }
    if (u.startsWith('/api/merchant/invoice/status')) { const id = u.split('=')[1]; const inv = invoices[id]; return send(200, { invoiceId: id, status: 'success', amount: inv.amount, finalAmount: inv.amount, reference: inv.merchantPaymInfo.reference }); }
    if (u === '/api/merchant/details') return send(200, { merchantName: 'ФОП Тест' });
    send(404, { error: 'nf ' + u });
  });
}).listen(4001, () => console.log('mock on 4001'));
